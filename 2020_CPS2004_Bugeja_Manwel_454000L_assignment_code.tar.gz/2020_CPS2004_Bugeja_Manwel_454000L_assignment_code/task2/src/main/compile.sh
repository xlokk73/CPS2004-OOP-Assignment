javac -d ../../out/production/task2 *.java
javac -d ../../out/test/task2 -classpath .:../../lib/* ../test/*.java
