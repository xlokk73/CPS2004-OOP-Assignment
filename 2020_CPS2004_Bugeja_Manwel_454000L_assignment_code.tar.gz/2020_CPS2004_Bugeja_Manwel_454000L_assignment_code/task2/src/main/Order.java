import java.util.ArrayList;

public class Order {
    protected String trader;
    protected String securityName;
    protected double price;
    protected int quantity;
    protected Long timestamp;
}
