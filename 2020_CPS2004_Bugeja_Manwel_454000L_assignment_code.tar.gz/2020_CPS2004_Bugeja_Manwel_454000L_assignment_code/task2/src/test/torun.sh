java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore TraderTest
java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore ListerTest
java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore SecurityTest
java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore BuyOrderTest
java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore SellOrderTest
java -cp ../../lib/junit-4.12.jar:../../lib/hamcrest-core-1.3.jar:../../out/test/task2/. org.junit.runner.JUnitCore ExchangePlatformTest
java -cp ../../out/production/task2/. Main