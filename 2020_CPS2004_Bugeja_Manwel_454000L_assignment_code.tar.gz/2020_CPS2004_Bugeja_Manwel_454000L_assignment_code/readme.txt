Task 1:
compile script: task1/compile.sh
run script: task1/torun.sh

Task 2:
compile script: task2/src/main/compile.sh
run script: task2/src/test/torun.sh

Task 3:
compile script: task3/compile.sh
run script: task3/torun.sh